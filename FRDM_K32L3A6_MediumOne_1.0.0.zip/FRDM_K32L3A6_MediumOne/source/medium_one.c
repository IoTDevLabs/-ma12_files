/* Routines for publishing data to Medium One */

/* NOTE: You must define PRINTF_ADVANCED_ENABLE = 1 at project level
 * to enable printing negative numbers in fsl_str.c:StrFormatPrintf().
 */

#include <stdio.h>
#include <stdlib.h>
#include "fsl_debug_console.h"
#include "qcom_api.h"
#include "wlan_qcom.h"
#include "medium_one.h"
#include "config.h"

#define INFO_PRINTF		PRINTF
#define DEBUG_PRINTF(args, ...)
//#define DEBUG_PRINTF	PRINTF

static int logged_in = 0;
static int https_port = 443;
static char hostname[80] = MEDIUMONE_HOSTNAME;
static char login_id[60] = MEDIUMONE_LOGIN_ID;
static char password[60] = MEDIUMONE_PASSWORD;
static char api_key[60]  = MEDIUMONE_APIKEY;
static int params_set = 1;

static char post_header[] =
"POST %s HTTP/1.1\r\n"						// path
"Host: %s\r\n"								// hostname
"User-Agent: embedded\r\n"
"Content-Type: application/json\r\n"
"Content-Length: %d\r\n\r\n"				// body content length
;

static char post_header_with_cookie[] =
"POST %s/%s HTTP/1.1\r\n"					// path incl device_id
"Host: %s\r\n"								// hostname
"User-Agent: embedded\r\n"
"Cookie: %s\r\n"							// cookies
"Content-Type: application/json\r\n"
"Content-Length: %d\r\n\r\n"				// body content length
;

#define MAX_RESPONSE_DATA	1400
static char response_data_buf[MAX_RESPONSE_DATA];

#define MAX_COOKIE_DATA		1400
static char cookie_data_buf[MAX_COOKIE_DATA];

// Convert IP address in uint32_t to comma separated bytes
#define UINT32_IPADDR_TO_CSV_BYTES(a) \
    ((uint8_t)((a) >> 24) & 0xFF), (uint8_t)(((a) >> 16) & 0xFF), (uint8_t)(((a) >> 8) & 0xFF), (uint8_t)((a)&0xFF)
// Convert comma separated bytes to a uint32_t IP address
#define CSV_BYTES_TO_UINT32_IPADDR(a0, a1, a2, a3) \
    (((uint32_t)(a0)&0xFF) << 24) | (((uint32_t)(a1)&0xFF) << 16) | (((uint32_t)(a2)&0xFF) << 8) | ((uint32_t)(a3)&0xFF)

static int httpsPost(char *request_data, int request_data_len, char *response_data, int response_data_max_len, int *response_data_actual_len)
{
	if (request_data == NULL || request_data == NULL) {
		return -1;
	}

	DEBUG_PRINTF("%s\r\n", request_data);

	int result = -1;

    int32_t sock = 0;
    SOCKADDR_T addr;
    A_STATUS status;
    SSL_CTX *sslCtx			= NULL;
    SSL *ssl				= NULL;
    uint32_t inputBufSize  	= 4500;
    uint32_t outputBufSize 	= 3000;
    int32_t res           	= A_ERROR;
    char *request_data_tx_buf;
    char *response_data_rx_buf;

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = ATH_AF_INET;
	addr.sin_addr.s_addr = resolveHostname(hostname);
	if (addr.sin_addr.s_addr == 0)
	{
		INFO_PRINTF("ERROR: Failed to resolve %s\r\n", hostname);
		return result;
	}
    addr.sin_port = https_port;

    /* NOTE: You must define PRINTF_ADVANCED_ENABLE = 1 at project level
     * to enable printing negative numbers in fsl_str.c:StrFormatPrintf().
     */

    do
    {

		/* Create SSL context */

    	DEBUG_PRINTF("Creating SSL context...\r\n");
		sslCtx = SSL_ctx_new(SSL_CLIENT, inputBufSize, outputBufSize, 0);
		DEBUG_PRINTF("SSL_ctx_new(SSL_CLIENT,%d,%d,%d) %x\r\n", inputBufSize, outputBufSize, 0, sslCtx);
		if (sslCtx == NULL)
		{
			INFO_PRINTF("ERROR: Unable to create SSL context\r\n");
			break;
		} else {
			DEBUG_PRINTF("SSL context created\r\n");
		}

		/* Root CA is not checked */

		/* Connect to server and perform operation */

        /* Create TCP socket */
		DEBUG_PRINTF("Creating TCP socket...\r\n");
        sock = qcom_socket(ATH_AF_INET, SOCK_STREAM_TYPE, 0);
        if (sock == -1) {
        	INFO_PRINTF("ERROR: Failed to create socket\r\n");
            break;
        } else {
        	DEBUG_PRINTF("Socket created\r\n");
        }

        /* Connect to remote */
        DEBUG_PRINTF("Connecting to remote server port %u...\r\n", addr.sin_port);
        status = (A_STATUS)qcom_connect(sock, (struct sockaddr *)&addr, sizeof(addr));
        if (status != A_OK) {
        	INFO_PRINTF("ERROR: Failed to connect to remote server\r\n");
            break;
        } else {
        	DEBUG_PRINTF("Socket connected to server\r\n");
        }

        /* Create SSL connection inst */

        DEBUG_PRINTF("Creating SSL connection instance...\r\n");
        ssl = SSL_new(sslCtx);
        DEBUG_PRINTF("SSL_new() %x\r\n", ssl);
        if (ssl == NULL)
        {
            INFO_PRINTF("ERROR: Unable to create SSL connection instance\r\n");
            res = A_ERROR;
            break;
        } else {
        	DEBUG_PRINTF("SSL connection instance created\r\n");
        }

        /* Add socket handle to SSL connection */

        DEBUG_PRINTF("Adding socket handle to SSL connection...\r\n");
        res = SSL_set_fd(ssl, sock /*socketHandle*/);
        DEBUG_PRINTF("SSL_set_fd() %d\r\n", res);
        if (res < 0)
        {
            INFO_PRINTF("ERROR: Unable to add socket handle to SSL\r\n");
            break;
        } else {
        	DEBUG_PRINTF("Socket handle added to SSL connection\r\n");
        }

        /* SSL handshake with server */

        DEBUG_PRINTF("Performing SSL connection handshake with server...\r\n");
        res = SSL_connect(ssl);
        DEBUG_PRINTF("SSL_connect() %d\r\n", (int)res);
        if (res < 0)
        {
            INFO_PRINTF("ERROR: SSL connect failed (%d)\r\n", res);
            switch (res) {
            	case ESSL_INVAL:
            		DEBUG_PRINTF("Invalid argument\r\n");
            		break;
            	case ESSL_NOSOCKET:
            		DEBUG_PRINTF("No more SSL socket descriptors available\r\n");
            		break;
            	case ESSL_HSNOTDONE:
            		DEBUG_PRINTF("Handshake not done\r\n");
            		break;
            	case ESSL_HSDONE:
            		DEBUG_PRINTF("Handshake already done\r\n");
            		break;
            	case ESSL_NOMEM:
            		DEBUG_PRINTF("Out of memory\r\n");
            		break;
            	case ESSL_CONN:
            		DEBUG_PRINTF("SharkSslCon_Error\r\n");
            		break;
            	case ESSL_CERT:
            		DEBUG_PRINTF("SharkSslCon_CertificateError\r\n");
            		break;
            	case ESSL_ALERTRECV:
            		DEBUG_PRINTF("SharkSslCon_AlertRecv\r\n");
            		break;
            	case ESSL_ALERTFATAL:
            		DEBUG_PRINTF("SharkSslCon_AlertSend FATAL received. Connection must be closed.\r\n");
            		break;
            	case ESSL_TIMEOUT:
            		DEBUG_PRINTF("Timeout during handshake\r\n");
            		break;
            	case ESSL_OOPS:
            		DEBUG_PRINTF("Oops (something is terribly wrong)\r\n");
            		break;
            	//case ESSL_OK_HANDSHAKE:
            	//	DEBUG_PRINTF("Handshake complete (internal reason code, not an error)\r\n");
            	//	break;
            	case ESSL_TRUST_CertCnTime:
					/** The peer's SSL certificate is trusted, CN matches the host name, time is valid */
            		DEBUG_PRINTF("The certificate is trusted\r\n");
            		DEBUG_PRINTF("Handshake complete (internal reason code, not an error)\r\n");
            		break;
				case ESSL_TRUST_CertCn:
					/** The peer's SSL certificate is trusted, CN matches the host name, time is expired */
					DEBUG_PRINTF("The certificate is expired\r\n");
            		break;
				case ESSL_TRUST_CertTime:
					/** The peer's SSL certificate is trusted, CN does NOT match the host name, time is valid */
					DEBUG_PRINTF("The certificate is trusted, but the host name is not valid\r\n");
            		break;
				case ESSL_TRUST_Cert:
					/** The peer's SSL certificate is trusted, CN does NOT match host name, time is expired */
					DEBUG_PRINTF("The certificate is expired and the host name is not valid\r\n");
            		break;
				case ESSL_TRUST_None:
					/** The peer's SSL certificate is NOT trusted */
					DEBUG_PRINTF("The certificate is NOT trusted\r\n");
            		break;
				default:
					DEBUG_PRINTF("Unknown SSL connect failure (%d)\r\n", res);
            		break;
            }
            break;  // stop processing
        } else {
        	DEBUG_PRINTF("SSL connection handshake completed\r\n");
        }

        /* Send HTTP request */

        DEBUG_PRINTF("HTTP POST to %u.%u.%u.%u:%u, request_data_len = %d\r\n",
        		UINT32_IPADDR_TO_CSV_BYTES(addr.sin_addr.s_addr), addr.sin_port, request_data_len);
        DEBUG_PRINTF("---------------------------\r\n");
        DEBUG_PRINTF("%s\r\n", request_data);
        DEBUG_PRINTF("---------------------------\r\n");
        request_data_tx_buf = custom_alloc(request_data_len);  // allocate network transfer buffer
        if (request_data_tx_buf == NULL) {
        	INFO_PRINTF("ERROR: Failed to allocate request data transmit buffer\r\n");
        	break;
        }
        memcpy(request_data_tx_buf, request_data, request_data_len);  // copy request data to transfer buffer
        int sent = qcom_send(sock, request_data_tx_buf, request_data_len, 0);
        DEBUG_PRINTF("TCP sent %d bytes\r\n", sent);

        /* Free transmit buffer */
        custom_free(request_data_tx_buf);
        request_data_tx_buf = NULL;
        if (sent < 0) {
        	INFO_PRINTF("ERROR: During socket send\r\n");
            break;
        }

        /* Block wait for response */
        DEBUG_PRINTF("Waiting for response (with t_select)\r\n");
        uint32_t timeout = 5000;
        QCA_CONTEXT_STRUCT *enetCtx = wlan_get_context();
        status                      = (A_STATUS)t_select(enetCtx, sock, timeout);
        if (status == A_ERROR) {
        	INFO_PRINTF("ERROR: During t_select()\r\n");
        	break;
        }

        /* Receive response */
        DEBUG_PRINTF("qcom_recv() receiving response\r\n");
        int recvLen = qcom_recv(sock, &response_data_rx_buf, MAX_RESPONSE_DATA, 0);
        DEBUG_PRINTF("TCP received %d bytes\r\n", recvLen);
        if (recvLen >= 0)
        {
            response_data_rx_buf[recvLen] = 0;
            DEBUG_PRINTF("---------------------------\r\n");
            DEBUG_PRINTF("%s\r\n", response_data_rx_buf);
            DEBUG_PRINTF("---------------------------\r\n");

            if (response_data != NULL && response_data_max_len > 0) {
            	/* Copy response data to destination buffer */
            	int copy_len = recvLen < response_data_max_len ? recvLen : response_data_max_len;
            	memcpy(response_data, response_data_rx_buf, copy_len);
            	if (response_data_actual_len != NULL) {
            		*response_data_actual_len = copy_len;
            	}
            }

            result = 0;
        } else {
        	INFO_PRINTF("ERROR: During socket receive\r\n");
        }

        /* Free receive buffer */
        if (response_data_rx_buf != NULL)
        {
            zero_copy_free(response_data_rx_buf);
        }

    } while (0);

    /* Shutdown SSL connection */

    if (ssl != NULL)
    {
        SSL_shutdown(ssl);
    }

    /* Free SSL context */

    if (sslCtx != NULL)
    {
        SSL_ctx_free(sslCtx);
    }

    /* Close socket */

    status = (A_STATUS)qcom_socket_close(sock);
    if (status != A_OK) {
    	DEBUG_PRINTF("ERROR: -1 on socket close\r\n");
    	// not treated as failure
    }

    return result;
}

static int login(void)
{
	/* Login to Medium One API */

	if (!params_set) {
		return -1;
	}
	char body[160];
	sprintf(body, "{\"login_id\":\"%s\",\"password\":\"%s\",\"api_key\":\"%s\"}",
			login_id, password, api_key);
	char request_data[256];
	sprintf(request_data, post_header, "/v2/login/", hostname, strlen(body));
	strcat(request_data, body);
	int response_len;
	if (httpsPost(request_data, strlen(request_data), response_data_buf, sizeof(response_data_buf), &response_len) != 0) {
		return -1;
	}

	/* Extract and save cookies */

	char *p = response_data_buf;
	char *q = cookie_data_buf;
	int source_count = 0;
	int dest_count = 0;
	int cookie_count = 0;
	while (source_count < response_len && dest_count < MAX_COOKIE_DATA) {
		if (strncmp(p, "auth_tkt=", 9) == 0 || strncmp(p, "session=", 8) == 0) {
			cookie_count++;
			while (*p != ';') {
				*q++ = *p++;
				source_count++;
				dest_count++;
			}
			*q++ = *p++;
			*q++ = ' ';
			dest_count++;
		} else {
			p++;
		}
		source_count++;
	}
	if (cookie_count > 0) {
		q--;
		while (q > response_data_buf && (*q == ' ' || *q == ';')) {
			q--;
		}
		q++;
	}
	*q = 0;

	DEBUG_PRINTF("Extracted cookies:\r\n");
	DEBUG_PRINTF("%s\r\n", cookie_data_buf);

	logged_in = 1;

	return 0;
}

int publishEvent(char *device_id, char *json_payload)
{
	/* Publish one event to Medium One API */

	if (json_payload == NULL) {
		return -1;
	}

	/* Login if not already logged in */

	if (!logged_in) {
		if (login() != 0) {
			return -1;
		}
	}

	/* Post event message containing json_payload */

	/* Cookie expiration is not currently checked */

	char request_data[1024];
	sprintf(request_data, post_header_with_cookie, "/v2/events/raw", device_id, hostname, cookie_data_buf, strlen(json_payload));
	strcat(request_data, json_payload);
	int response_len;
	if (httpsPost(request_data, strlen(request_data), response_data_buf, sizeof(response_data_buf), &response_len) != 0) {
		return -1;
	}

	return 0;
}
