/* Configuration parameters */

/* Wi-Fi connection */
#define WIFI_SSID			"YOUR_SSID"
#define WIFI_PASSWORD		"YOUR_PASSWORD"
#define WIFI_AUTH			WLAN_AUTH_WPA2_PSK		/* enum WLAND_AUTH_MODE in qcom_api.h */
#define WIFI_CIPHER			WLAN_CRYPT_AES_CRYPT	/* enum WLAN_CRYPT_TYPE in qcom_api.h */

/* Medium One parameters */
#define MEDIUMONE_HOSTNAME	"api.mediumone.com"
#define MEDIUMONE_LOGIN_ID	"mydevice"
#define MEDIUMONE_PASSWORD	"YOUR_PASSWORD"
#define MEDIUMONE_APIKEY	"YOUR_APIKEY"
#define MEDIUMONE_DEVICE_ID	"mydevice"
