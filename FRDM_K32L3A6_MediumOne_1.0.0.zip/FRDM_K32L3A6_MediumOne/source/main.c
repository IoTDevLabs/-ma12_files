/*
 * Copyright (c) 2013 - 2014, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

///////////////////////////////////////////////////////////////////////////////
//  Includes
///////////////////////////////////////////////////////////////////////////////

// SDK Included Files
#include "stdio.h"
#include "board.h"
#include "fsl_debug_console.h"
#include "qcom_api.h"
#include "wlan_qcom.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_fxos.h"
#include "math.h"
#include "medium_one.h"
#include "config.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

void BOARD_I2C_ReleaseBus(void);
static int init_accel(void);
int read_accel(int16_t *xAngle_result, int16_t *yAngle_result, int16_t *zAngle_result);

/*******************************************************************************
 * Code
 ******************************************************************************/

// 0 is the highest priority and priority 15 is the lowest priority
const int TASK_MAIN_PRIO       = configMAX_PRIORITIES - 3;
const int TASK_MAIN_STACK_SIZE = 800;

portSTACK_TYPE *task_main_stack = NULL;
TaskHandle_t task_main_task_handler;

// Hardwired SSID, passphrase, auth and cipher algo of AP to connect to
#define AP_SSID			WIFI_SSID			/* from config.h */
#define AP_PASSPHRASE	WIFI_PASSWORD		/* from config.h */

QCOM_SSID g_ssid             = {.ssid = (AP_SSID)};
QCOM_PASSPHRASE g_passphrase = {.passphrase = (AP_PASSPHRASE)};

WLAN_AUTH_MODE g_auth    = WIFI_AUTH;		/* from config.h */
WLAN_CRYPT_TYPE g_cipher = WIFI_CIPHER;		/* from config.h */

// ============================================================================
// Menu Handling
// ============================================================================

extern int numIrqs;
extern int initTime;

// ============================================================================
// Main
// ============================================================================

static void print_version(void)
{
    ATH_VERSION_STR verstr;

    int res = qcom_get_versionstr(&verstr);
    if (A_OK == res)
    {
        PRINTF("Host version:      %s\r\n", verstr.host_ver);
        PRINTF("Target version:    %s\r\n", verstr.target_ver);
        PRINTF("Firmware version:  %s\r\n", verstr.wlan_ver);
        PRINTF("Interface version: %s\r\n", verstr.abi_ver);
    }
    else
    {
        PRINTF("ERROR: Failed to get QCA400X version information\r\n");
    }
}

void task_main(void *param)
{
    int32_t result = 0;
    (void)result;

    /* Initialize WIFI shield */
    result = WIFISHIELD_Init();
    assert(A_OK == result);

    /* Initialize the WIFI driver (thus starting the driver task) */
    result = wlan_driver_start();
    assert(A_OK == result);

    print_version();

    // UBaseType_t numTasks = uxTaskGetNumberOfTasks();
    // PRINTF("Number of FreeRTOS tasks = %d\r\n", numTasks);
    // DbgConsole_Flush();

    /* Connect to Wi-Fi and get DHCP address */

	while (!isConnected()) {
		PRINTF("Connecting to Wi-Fi SSID '%s'...\r\n", AP_SSID);
		apConnect(&g_ssid, &g_passphrase, g_auth, g_cipher);
		while (!isConnected()) {
			if (connectFailed()) {
				PRINTF("Connect failed, retrying in 5 seconds...\r\n");
				vTaskDelay(MSEC_TO_TICK(5000));
				break;
			} else {
				vTaskDelay(MSEC_TO_TICK(250));
			}
		}
    }
    PRINTF("Connected to Wi-Fi\r\n");

    getDhcp();

    /* Main loop */

    uint32_t loop_delay_ms = 3000;	// 3 seconds

    int16_t xAccel, yAccel, zAccel;
    char msg[80];

    PRINTF("Starting read & publish loop\r\n");

    while (1) {

    	if (read_accel(&xAccel, &yAccel, &zAccel) == 0) {
    		//PRINTF("xAccel = %3d, yAccel=%3d, zAccel=%3d\r\n", xAccel, yAccel, zAccel);
    		sprintf(msg, "{\"event_data\":{\"xAccel\":%d,\"yAccel\":%d,\"zAccel\":%d}}", xAccel, yAccel, zAccel);
    		PRINTF("Publishing %s\r\n", msg);
    		publishEvent(MEDIUMONE_DEVICE_ID, msg);
    	} else {
    		PRINTF("ERROR: Read accelerometer failed\r\n");
    	}

    	vTaskDelay(MSEC_TO_TICK(loop_delay_ms));

    }
}

int main(void)
{
    BaseType_t result = 0;
    (void)result;

    CLOCK_EnableClock(kCLOCK_Rgpio1);
    BOARD_InitPins();
    BOARD_BootClockRUN();

    BOARD_I2C_ReleaseBus();
    BOARD_I2C_ConfigurePins();
    init_accel();

    BOARD_InitDebugConsole();

    result =
        xTaskCreate(task_main, "main", TASK_MAIN_STACK_SIZE, task_main_stack, TASK_MAIN_PRIO, &task_main_task_handler);
    assert(pdPASS == result);

    vTaskStartScheduler();
    for (;;)
        ;
}

/* Onboard I2C Accelerometer */

/* LPI2C */
#define I2C_BAUDRATE 100000U

#define I2C_RELEASE_SDA_PORT PORTE
#define I2C_RELEASE_SCL_PORT PORTE
#define I2C_RELEASE_SDA_GPIO GPIOE
#define I2C_RELEASE_SDA_PIN 29U
#define I2C_RELEASE_SCL_GPIO GPIOE
#define I2C_RELEASE_SCL_PIN 30U
#define I2C_RELEASE_BUS_COUNT 100U

/* FXOS device address */
const uint8_t g_accel_address[] = {0x1CU, 0x1DU, 0x1EU, 0x1FU};

static void i2c_release_bus_delay(void)
{
    uint32_t i = 0;
    for (i = 0; i < I2C_RELEASE_BUS_COUNT; i++)
    {
        __NOP();
    }
}

void BOARD_I2C_ReleaseBus(void)
{
    uint8_t i = 0;
    gpio_pin_config_t pin_config;
    port_pin_config_t i2c_pin_config = {0};

    /* Config pin mux as gpio */
    i2c_pin_config.pullSelect = kPORT_PullUp;
    i2c_pin_config.mux        = kPORT_MuxAsGpio;

    pin_config.pinDirection = kGPIO_DigitalOutput;
    pin_config.outputLogic  = 1U;
    CLOCK_EnableClock(kCLOCK_PortE);
    PORT_SetPinConfig(I2C_RELEASE_SCL_PORT, I2C_RELEASE_SCL_PIN, &i2c_pin_config);
    PORT_SetPinConfig(I2C_RELEASE_SDA_PORT, I2C_RELEASE_SDA_PIN, &i2c_pin_config);

    GPIO_PinInit(I2C_RELEASE_SCL_GPIO, I2C_RELEASE_SCL_PIN, &pin_config);
    GPIO_PinInit(I2C_RELEASE_SDA_GPIO, I2C_RELEASE_SDA_PIN, &pin_config);

    /* Drive SDA low first to simulate a start */
    GPIO_PinWrite(I2C_RELEASE_SDA_GPIO, I2C_RELEASE_SDA_PIN, 0U);
    i2c_release_bus_delay();

    /* Send 9 pulses on SCL and keep SDA high */
    for (i = 0; i < 9; i++)
    {
        GPIO_PinWrite(I2C_RELEASE_SCL_GPIO, I2C_RELEASE_SCL_PIN, 0U);
        i2c_release_bus_delay();

        GPIO_PinWrite(I2C_RELEASE_SDA_GPIO, I2C_RELEASE_SDA_PIN, 1U);
        i2c_release_bus_delay();

        GPIO_PinWrite(I2C_RELEASE_SCL_GPIO, I2C_RELEASE_SCL_PIN, 1U);
        i2c_release_bus_delay();
        i2c_release_bus_delay();
    }

    /* Send stop */
    GPIO_PinWrite(I2C_RELEASE_SCL_GPIO, I2C_RELEASE_SCL_PIN, 0U);
    i2c_release_bus_delay();

    GPIO_PinWrite(I2C_RELEASE_SDA_GPIO, I2C_RELEASE_SDA_PIN, 0U);
    i2c_release_bus_delay();

    GPIO_PinWrite(I2C_RELEASE_SCL_GPIO, I2C_RELEASE_SCL_PIN, 1U);
    i2c_release_bus_delay();

    GPIO_PinWrite(I2C_RELEASE_SDA_GPIO, I2C_RELEASE_SDA_PIN, 1U);
    i2c_release_bus_delay();
}

fxos_handle_t fxosHandle = {0};
uint8_t dataScale = 0;

int init_accel(void)
{
    fxos_config_t config     = {0};
    status_t result;
    uint8_t sensorRange     = 0;
    uint8_t i               = 0;
    uint8_t array_addr_size = 0;

    /* Clock */
    CLOCK_SetIpSrc(kCLOCK_Lpi2c3, kCLOCK_IpSrcFircAsync);

    /* I2C initialize */
    BOARD_Accel_I2C_Init();
    /* Configure the I2C function */
    config.I2C_SendFunc    = BOARD_Accel_I2C_Send;
    config.I2C_ReceiveFunc = BOARD_Accel_I2C_Receive;

    /* Initialize sensor devices */
    array_addr_size = sizeof(g_accel_address) / sizeof(g_accel_address[0]);
    for (i = 0; i < array_addr_size; i++)
    {
        config.slaveAddress = g_accel_address[i];
        /* Initialize accelerometer sensor */
        result = FXOS_Init(&fxosHandle, &config);
        if (result == kStatus_Success)
        {
            break;
        }
    }

    if (result != kStatus_Success)
    {
        PRINTF("\r\nSensor device initialize failed!\r\n");
        return -1;
    }

    /* Get sensor range */
    if (FXOS_ReadReg(&fxosHandle, XYZ_DATA_CFG_REG, &sensorRange, 1) != kStatus_Success)
    {
        return -1;
    }

    if (sensorRange == 0x00)
    {
        dataScale = 2U;
    }
    else if (sensorRange == 0x01)
    {
        dataScale = 4U;
    }
    else if (sensorRange == 0x10)
    {
        dataScale = 8U;
    }
    else
    {
    }

    return 0;
}

int read_accel(int16_t *xAngle_result, int16_t *yAngle_result, int16_t *zAngle_result)
{
	fxos_data_t sensorData   = {0};
    int16_t xData           = 0;
    int16_t yData           = 0;
    int16_t zData           = 0;
    int16_t xAngle          = 0;
    int16_t yAngle          = 0;
    int16_t zAngle          = 0;
    int16_t xAngle_raw      = 0;
    int16_t yAngle_raw      = 0;
    int16_t zAngle_raw      = 0;

    /* Get new accelerometer data. */
    if (FXOS_ReadSensorData(&fxosHandle, &sensorData) != kStatus_Success)
    {
        return -1;
    }

    /* Get the X and Y data from the sensor data structure in 14 bit left format data*/
    xData = (int16_t)((uint16_t)((uint16_t)sensorData.accelXMSB << 8) | (uint16_t)sensorData.accelXLSB) / 4U;
    yData = (int16_t)((uint16_t)((uint16_t)sensorData.accelYMSB << 8) | (uint16_t)sensorData.accelYLSB) / 4U;
    zData = (int16_t)((uint16_t)((uint16_t)sensorData.accelZMSB << 8) | (uint16_t)sensorData.accelZLSB) / 4U;

    /* Convert raw data to angle (normalize to 0-90 degrees). No negative angles. */
    xAngle_raw = xAngle = (int16_t)floor((double)xData * (double)dataScale * 90 / 8192);
    yAngle_raw = yAngle = (int16_t)floor((double)yData * (double)dataScale * 90 / 8192);
    zAngle_raw = zAngle = (int16_t)floor((double)zData * (double)dataScale * 90 / 8192);

    if (xAngle_raw < -90) {
    	xAngle_raw = -90;
    } else if (xAngle_raw > 90) {
    	xAngle_raw = 90;
    }
    if (yAngle_raw < -90) {
    	yAngle_raw = -90;
    } else if (yAngle_raw > 90) {
    	yAngle_raw = 90;
    }
    if (zAngle_raw < -90) {
    	zAngle_raw = -90;
    } else if (zAngle_raw > 90) {
    	zAngle_raw = 90;
    }

    /* Absolute value angles */
    if (xAngle < 0)
    {
        xAngle *= -1;
    }
    if (yAngle < 0)
    {
        yAngle *= -1;
    }
    if (zAngle < 0)
    {
        zAngle *= -1;
    }

    *xAngle_result = xAngle_raw;
    *yAngle_result = yAngle_raw;
    *zAngle_result = zAngle_raw;

    return 0;
}
