/* Routines for publishing data to Medium One */

int publishEvent(char *device_id, char *json_payload);
